// Will be removed after the 2.7 release
#warning "Deprecated header, use #include <dune/common/parallel/mpicommunication.hh> instead!"
#include <dune/common/parallel/mpicommunication.hh>
