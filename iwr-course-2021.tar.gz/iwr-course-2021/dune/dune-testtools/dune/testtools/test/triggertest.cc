#include SWITCH1_CONDITIONAL_INCLUDE(dune/testtools/test/trigger1.hh)
#include SWITCH2_CONDITIONAL_INCLUDE(dune/testtools/test/trigger1.hh)

int main()
{
  return 0;
}
