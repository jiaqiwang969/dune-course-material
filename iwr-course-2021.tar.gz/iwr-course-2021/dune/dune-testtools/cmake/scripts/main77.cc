int main()
{
  return 77;
}
