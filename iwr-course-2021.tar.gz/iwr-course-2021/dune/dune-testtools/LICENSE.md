Copyright holders:
------------------

* 2014 -- 2018 Dominic Kempf
* 2014 -- 2018 Timo Koch
* 2015         Rene Milk
* 2015         Linus Seelinger

The module dune-testtools is free software and documentation.

You can use, modify and/or redistribute the contained software (in the directory
src/) under the terms of the BSD 3-clause license, which you can find in the
file BSD.

The documentation in the directory doc/ is licensed under the Creative Commons
Attribution-ShareAlike 3.0 Unported License. You can find a copy of this license
in the file CC-BY-SA. If not, see http://creativecommons.org/licenses/by-sa/3.0/
or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain
View, California, 94041, USA.
