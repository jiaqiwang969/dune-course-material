""" This submodule offers functionality equivalent to the
C++ ini file parser in python """
