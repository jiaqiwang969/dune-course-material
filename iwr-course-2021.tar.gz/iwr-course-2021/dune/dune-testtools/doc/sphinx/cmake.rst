CMake documentation of dune-testools
************************************

CMake Command reference
=======================
.. toctree::
   :maxdepth: 1
   :glob:

   commands/*

CMake Module reference
======================
.. toctree::
   :maxdepth: 1
   :glob:

   modules/*

CMake Variable reference
========================
.. toctree::
   :maxdepth: 1
   :glob:

   variables/*
