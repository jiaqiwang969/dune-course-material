The documentation of ``dune-testtools``
***************************************

The documentation of the dune module ``dune-testtools``. ``dune-testtools``
provides tools for system testing in numerical software frameworks
like Dune.

Content
==================

.. toctree::
   :maxdepth: 2

   quickstartdune
   metaini
   what
   testingtesttools
   cmake
   python

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
