#ifndef DUNE_TYPETREE_TEST_TYPETREESWITCH_HH
#define DUNE_TYPETREE_TEST_TYPETREESWITCH_HH


#ifdef TEST_TYPETREE

// nothing to do right now - no fallback code to test...

#else
#error You need to specify a test case via preprocessor define!
#endif


#endif // DUNE_TYPETREE_TEST_TYPETREESWITCH_HH
